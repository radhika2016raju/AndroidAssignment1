package com.example.myassignment1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

            lateinit var et_username: EditText
            lateinit var et_password: EditText
            lateinit var btn_login: Button

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContentView(R.layout.activity_main)

                btn_login = findViewById(R.id.btn_login) as Button
                et_username= findViewById(R.id.et_username)
                et_password= findViewById(R.id.et_password)

                btn_login.setOnClickListener {
                    val UserName= et_username.text.toString()
                    val Password= et_password.text.toString()

                    if (UserName.isEmpty()){
                        et_username.error="Required"
                        et_username.requestFocus()
                        return@setOnClickListener
                    }
                    if (Password.isEmpty()){
                        et_password.error="Required"
                        et_password.requestFocus()
                        return@setOnClickListener
                    }
                    if  (UserName.equals("admin")&& Password.equals("123") ){
                        val intent:Intent=Intent(this,HomeActivity::class.java)
                        startActivity(intent)
                    }
                    else{
                        Toast.makeText(this,"Entered UserName and Password is Wrong", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }


