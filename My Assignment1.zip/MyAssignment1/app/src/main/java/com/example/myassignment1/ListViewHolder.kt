package com.example.myassignmenttask

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myassignment1.R

class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tv_id: TextView = itemView.findViewById(R.id.tv_id)
        var tv_UserName: TextView = itemView.findViewById(R.id.tv_UserName)
        var tv_emailid: TextView = itemView.findViewById(R.id.tv_emailid)

    }