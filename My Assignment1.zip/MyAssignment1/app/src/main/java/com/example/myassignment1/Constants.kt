package com.example.myassignmenttask
    const val USER_NAME="admin"
     const val PASSWORD="123"
     val userList= mutableListOf<UserDetails>()

