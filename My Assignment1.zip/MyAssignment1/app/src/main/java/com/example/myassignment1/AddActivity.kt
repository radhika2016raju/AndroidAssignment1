package com.example.myassignment1

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myassignmenttask.RecyclerAdapter
import com.example.myassignmenttask.UserDetails
import com.google.android.material.floatingactionbutton.FloatingActionButton

class AddActivity: AppCompatActivity() {
    private lateinit var addsBtn:FloatingActionButton
    private lateinit var recv:RecyclerView
    private lateinit var userList:ArrayList<UserDetails>
    private lateinit var recyclerAdapter:RecyclerAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adduser)
        /**set List*/
        userList = ArrayList()
        /**set find Id*/
        addsBtn = findViewById(R.id.addingBtn)
        recv = findViewById(R.id.mRecycler)
        /**set Adapter*/
        recyclerAdapter = RecyclerAdapter(this,userList)
        /**setRecycler view Adapter*/
        recv.layoutManager = LinearLayoutManager(this)
        recv.adapter = recyclerAdapter
        /**set Dialog*/
        addsBtn.setOnClickListener { addInfo() }

    }

    private fun addInfo() {
        val inflter = LayoutInflater.from(this)
        val v = inflter.inflate(R.layout.edit_item,null)
        /**set view*/
        val userName = v.findViewById<EditText>(R.id.et_name)
       val userid = v.findViewById<EditText>(R.id.et_id)
       val email = v.findViewById<EditText>(R.id.et_email)

        val addDialog = AlertDialog.Builder(this)
        addDialog.setView(v)
        addDialog.setPositiveButton("ADD"){
                dialog,_->
            val names = userName.text.toString()
            val email = email.text.toString()
            val id = userid.text.toString()

            userList.add(UserDetails("UserId: $id","UserName:$names","email:$email"))
            recyclerAdapter.notifyDataSetChanged()


            Toast.makeText(this,"Adding User Information Success", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        addDialog.setNegativeButton("CANCEL"){
                dialog,_->
            dialog.dismiss()
            Toast.makeText(this,"Cancel", Toast.LENGTH_SHORT).show()

        }
        addDialog.create()
        addDialog.show()
    }

    }
    /**ok now run this */
