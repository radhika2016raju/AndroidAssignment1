package com.example.myassignment1

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.myassignmenttask.UserDetails

class HomeActivity: AppCompatActivity() {
    private lateinit var btn_adduser: Button
    private lateinit var btn_show: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        btn_adduser = findViewById(R.id.btn_adduser)
        btn_show = findViewById(R.id.btn_showlist)
        btn_adduser.setOnClickListener {
            val intent: Intent = Intent(this, AddActivity::class.java)
            startActivity(intent)
        }
        btn_show.setOnClickListener {
            val intent: Intent = Intent(this, AddActivity::class.java)
            startActivity(intent)

        }

    }
    }




