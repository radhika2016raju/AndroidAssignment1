package com.example.myassignmenttask

data class UserDetails internal constructor(
    var Userid:String,
    var Username: String,
    var email: String)