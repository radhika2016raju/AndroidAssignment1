package com.example.myassignmenttask

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.example.myassignment1.R

class RecyclerAdapter(val context:Context,val userList:ArrayList<UserDetails>)
    :RecyclerView.Adapter<RecyclerAdapter.ListViewHolder>()
{
    inner class ListViewHolder(val v: View):RecyclerView.ViewHolder(v) {
        var username: TextView
        var userid: TextView
        var email: TextView

        init {
            username = v.findViewById<TextView>(R.id.tv_UserName)
            userid = v.findViewById<TextView>(R.id.tv_id)
            email = v.findViewById<TextView>(R.id.tv_emailid)


        }
    }

        override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
            val newList = userList[position]
            holder.username.text = newList.Username
            holder.userid.text = newList.Userid
            holder.email.text = newList.email
        }
            override fun getItemCount(): Int {
                return userList.size
            }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
            val inflater = LayoutInflater.from(parent.context)
            val v  = inflater.inflate(R.layout.list_item,parent,false)
            return ListViewHolder(v)

                    }
                }

